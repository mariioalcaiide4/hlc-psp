package actividad2;

public class Cliente {
}
