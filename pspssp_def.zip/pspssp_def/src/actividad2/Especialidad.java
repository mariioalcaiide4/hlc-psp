package actividad2;

public class Especialidad {
    int id;
    String nombreEsp;

    public Especialidad(int id, String nombreEsp) {
        this.id = id;
        this.nombreEsp = nombreEsp;
    }

    public int getId() {
        return id;
    }

    public String getNombreEsp() {
        return nombreEsp;
    }
}

